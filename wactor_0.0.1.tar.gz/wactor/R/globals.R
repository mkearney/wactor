utils::globalVariables(c("w", "term", "term_count"))
