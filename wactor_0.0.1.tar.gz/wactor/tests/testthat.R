library(testthat)
library(wactor)

test_check("wactor")
